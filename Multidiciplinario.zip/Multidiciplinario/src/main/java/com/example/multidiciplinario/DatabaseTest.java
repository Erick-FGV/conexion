package com.example.multidiciplinario;

import java.sql.Connection;

public class DatabaseTest {
    public static void main(String[] args) {
        Connection connection = DatabaseConnection.getConnection();
        if (connection != null) {
            System.out.println("Conexión a la base de datos establecida exitosamente.");
        } else {
            System.out.println("Fallo al establecer la conexión a la base de datos.");
        }
    }
}
